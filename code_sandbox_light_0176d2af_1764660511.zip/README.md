# +2 Study Path Advisor

An intelligent web application that helps students transitioning from 10th to +2 (11th-12th grade) discover the most suitable study paths based on their interests, strengths, and career aspirations.

## 🎯 Project Overview

This interactive advisor guides students through a carefully designed 5-question questionnaire to understand their:
- Academic interests and favorite subjects
- Career aspirations and goals
- Preferred learning styles
- Core strengths and abilities
- Long-term educational and professional objectives

Based on the responses, the system provides personalized recommendations for study streams including Science (PCM/PCB), Commerce, Arts/Humanities, Vocational courses, and Interdisciplinary programs.

## ✨ Currently Completed Features

### 1. **Welcome & Introduction Screen**
- Eye-catching hero section with clear value proposition
- Overview of what the questionnaire covers
- Animated graduation cap icon
- "Start Your Journey" call-to-action button

### 2. **Interactive Questionnaire System**
- **5 Comprehensive Questions:**
  1. Subject interests (Science, Commerce, Arts, Technical)
  2. Career preferences (Technology, Healthcare, Business, Creative, Social Service)
  3. Learning style (Analytical, Practical, Creative, Research-oriented)
  4. Strongest skills and abilities
  5. Long-term educational and career goals

- **Features:**
  - Visual progress bar showing completion percentage
  - Beautiful card-based option selection with icons
  - Previous/Next navigation with answer retention
  - Responsive design for all devices
  - Smooth animations and transitions

### 3. **Intelligent Recommendation Engine**
- Tag-based scoring system analyzing student responses
- Calculates match percentages for each stream
- Considers multiple factors: interests, skills, career goals, learning preferences
- Provides top 3 personalized recommendations ranked by compatibility

### 4. **Comprehensive Study Path Database**
Detailed information for each stream:

#### **Science Stream (PCM/PCB)**
- Subjects: Physics, Chemistry, Math/Biology options
- Careers: Engineering, Medicine, Research, Data Science, Biotechnology
- Entrance Exams: JEE, NEET, BITSAT, AIIMS
- Top Colleges: IITs, AIIMS, NITs, BITS Pilani, IISc

#### **Commerce Stream**
- Subjects: Accountancy, Business Studies, Economics
- Careers: CA, CS, CMA, Business Management, Banking, Finance
- Entrance Exams: CA Foundation, CS Foundation, IPMAT
- Top Colleges: SRCC, St. Xavier's, Christ University

#### **Arts/Humanities Stream**
- Subjects: History, Political Science, Psychology, Sociology, Literature
- Careers: Civil Services, Law, Journalism, Education, Social Work, Design
- Entrance Exams: UPSC, CLAT, CUET, NIFT, NID
- Top Colleges: St. Stephen's, JNU, DU colleges, TISS, NLUs

#### **Vocational/Technical Courses**
- Programs: IT, Web/App Development, Design, Hotel Management, Fashion
- Careers: Developer, Designer, Chef, Fashion Designer, Technician
- Entrance Exams: ITI, Polytechnic, NIFT, NCHMCT JEE
- Institutes: ITIs, Polytechnics, NIFT, IHM, Pearl Academy

#### **Interdisciplinary Options**
- Programs: Liberal Arts, Business Analytics, Environmental Science
- Careers: Business Analyst, UX Researcher, Sustainability Expert
- Top Colleges: Ashoka University, Flame University, Azim Premji University

### 5. **Results & Recommendations Display**
- **Top 3 matched streams** with percentage compatibility
- **Detailed breakdown for each recommendation:**
  - Complete subject list with descriptions
  - 8+ career opportunities
  - Key entrance examinations
  - Top 6 colleges/institutions
  - Skills students will develop
  - Why this path matches their profile

- **Visual hierarchy:**
  - Primary recommendation (highest match) - green accent
  - Secondary recommendation - blue accent
  - Tertiary recommendation - orange accent

### 6. **User Experience Features**
- Print-friendly results page
- "Start Over" functionality to retake the questionnaire
- Responsive design for mobile, tablet, and desktop
- Modern gradient background and card-based UI
- Font Awesome icons throughout
- Smooth animations and transitions

## 📁 Project Structure

```
+2-study-path-advisor/
│
├── index.html                 # Main HTML structure
├── css/
│   └── style.css             # Complete styling and responsive design
├── js/
│   ├── questions.js          # Question database with 5 questions
│   ├── recommendations.js    # Study paths data and recommendation engine
│   └── main.js              # Application logic and UI interactions
└── README.md                 # This file
```

## 🚀 How to Use

1. **Start the Application:**
   - Open `index.html` in any modern web browser
   - Click "Start Your Journey" on the welcome screen

2. **Answer Questions:**
   - Read each question carefully
   - Click on the option that best describes you
   - Use Previous/Next buttons to navigate
   - Your answers are saved automatically

3. **Review Recommendations:**
   - After answering all 5 questions, click "Get Recommendations"
   - Review your personalized study path suggestions
   - Explore career options, colleges, and entrance exams
   - Print results for future reference

4. **Retake (Optional):**
   - Click "Start Over" to answer questions again
   - Try different answers to explore various paths

## 🎨 Design Highlights

- **Color Scheme:**
  - Primary: Indigo (#6366f1)
  - Success: Green (#10b981)
  - Background: Gradient (Purple to Violet)
  - Clean white cards with subtle shadows

- **Typography:**
  - Inter font family for modern, clean look
  - Clear hierarchy with varied font sizes and weights

- **Responsive Design:**
  - Mobile-first approach
  - Breakpoints at 768px for tablets and smaller devices
  - Print-optimized layout

## 🔧 Technical Implementation

### Recommendation Algorithm

The system uses a weighted tag-based scoring mechanism:

1. **Tag Collection:** Each answer option has associated tags (e.g., "science", "analytical", "creative")
2. **Score Calculation:** Different streams receive weighted scores based on tag frequencies
3. **Match Percentage:** Normalized to show relative compatibility (0-100%)
4. **Top 3 Selection:** Highest-scoring streams are selected as recommendations

### Data Structure

- **Questions Array:** 5 objects with question text, icons, and multiple-choice options
- **Study Paths Object:** Comprehensive data for each stream including subjects, careers, exams, colleges
- **State Management:** Tracks current question index and user answers array

## 🌟 Key Benefits

- **Student-Centric:** Focuses on individual interests and strengths
- **Comprehensive:** Covers all major +2 study options in India
- **Informative:** Provides detailed career, college, and exam information
- **Accessible:** No login required, works offline after loading
- **User-Friendly:** Simple, intuitive interface with clear guidance

## 📋 Features Not Yet Implemented

### Potential Enhancements (Future Scope)

1. **Data Persistence:**
   - Save results to browser localStorage
   - Allow students to access previous results

2. **Detailed Reports:**
   - Generate downloadable PDF reports
   - Email results to students

3. **Extended Question Bank:**
   - Optional personality assessment questions
   - Subject-wise aptitude mini-tests

4. **College & Exam Explorer:**
   - Detailed college profiles with fees, placements
   - Exam preparation resources and timelines

5. **Career Path Visualization:**
   - Interactive career roadmaps
   - Success stories from each stream

6. **Counselor Dashboard:**
   - Allow teachers/counselors to track student assessments
   - Bulk assessment for school programs

7. **Multilingual Support:**
   - Hindi, regional languages
   - Voice-based questionnaire option

8. **Social Features:**
   - Share results with parents/teachers
   - Connect with students in similar streams

## 🎯 Recommended Next Steps

1. **User Testing:**
   - Test with real +2 students
   - Gather feedback on question clarity
   - Validate recommendation accuracy

2. **Content Enhancement:**
   - Add more career examples for each stream
   - Include salary ranges and job prospects
   - Add video testimonials from professionals

3. **Mobile App Version:**
   - Convert to Progressive Web App (PWA)
   - Native mobile apps for iOS/Android

4. **Integration with Educational Platforms:**
   - Partner with schools and coaching centers
   - Integration with career counseling services

5. **Analytics Dashboard:**
   - Track most popular streams
   - Analyze student trends by region/demographic

## 📱 Browser Compatibility

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Opera 76+

## 📄 License

This is an educational project created to help students make informed decisions about their academic future.

## 🤝 Contributing

This project is designed to be easily extensible. To add new features:
- Add new questions in `js/questions.js`
- Extend study paths in `js/recommendations.js`
- Modify recommendation logic in the `calculateRecommendations()` function

## 💡 Tips for Students

1. **Be Honest:** Answer based on your true interests, not what others expect
2. **Consider Strengths:** Choose paths that align with your natural abilities
3. **Research Further:** Use recommendations as a starting point for deeper exploration
4. **Consult Experts:** Discuss results with parents, teachers, and career counselors
5. **Stay Flexible:** Your interests may evolve; that's perfectly normal

## 📞 Support & Feedback

For questions, suggestions, or feedback about improving this advisor, students and educators can use this tool freely to explore educational options.

---

**Made with ❤️ for aspiring +2 students across India**

*Empowering students to make informed decisions about their future.*