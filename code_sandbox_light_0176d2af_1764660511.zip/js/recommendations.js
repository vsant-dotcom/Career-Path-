// Comprehensive study path recommendations database
const studyPaths = {
    science: {
        title: "Science Stream (PCM/PCB)",
        badge: "Best Match",
        description: "The Science stream opens doors to some of the most sought-after and innovative career paths. With a strong foundation in scientific principles and analytical thinking, you'll be prepared for careers in technology, healthcare, research, and engineering.",
        subjects: {
            pcm: {
                title: "Physics, Chemistry, Mathematics (PCM)",
                list: [
                    "Physics - Study of matter, energy, and the fundamental forces",
                    "Chemistry - Understanding matter and its interactions",
                    "Mathematics - Advanced calculus, algebra, and problem-solving",
                    "English - Communication and language skills",
                    "Optional: Computer Science, Physical Education, or Other Language"
                ]
            },
            pcb: {
                title: "Physics, Chemistry, Biology (PCB)",
                list: [
                    "Physics - Fundamental principles for medical equipment understanding",
                    "Chemistry - Biochemistry and pharmaceutical foundations",
                    "Biology - Human anatomy, physiology, and life sciences",
                    "English - Medical communication and documentation",
                    "Optional: Mathematics, Physical Education, or Psychology"
                ]
            }
        },
        careers: [
            "Engineering (Computer Science, Mechanical, Electrical, Civil, Aerospace)",
            "Medical Doctor (MBBS, BDS, BAMS, BHMS, Veterinary)",
            "Research Scientist in Physics, Chemistry, Biology, or Environmental Science",
            "Data Scientist, Software Developer, AI/ML Engineer",
            "Biotechnology Specialist, Genetic Engineer",
            "Pharmacy, Nursing, Physiotherapy, Medical Lab Technology",
            "Architecture, Astronomer, Geologist, Marine Biologist",
            "Forensic Scientist, Agricultural Scientist"
        ],
        entranceExams: [
            "JEE Main & Advanced (Engineering)",
            "NEET (Medical)",
            "BITSAT, VITEEE, COMEDK (Private Engineering)",
            "AIIMS, JIPMER (Medical)",
            "NATA (Architecture)",
            "IISER, NEST (Research)"
        ],
        topColleges: [
            "IITs (Indian Institutes of Technology) - Multiple locations",
            "AIIMS (All India Institute of Medical Sciences) - Multiple locations",
            "NITs (National Institutes of Technology) - Multiple locations",
            "BITS Pilani, IISc Bangalore, IISERs",
            "Delhi University, Mumbai University, Top State Medical Colleges",
            "Manipal Institute, VIT, SRM University"
        ],
        skills: [
            "Strong analytical and problem-solving abilities",
            "Mathematical and logical reasoning",
            "Scientific temperament and curiosity",
            "Attention to detail and precision",
            "Research and experimental skills"
        ]
    },
    
    commerce: {
        title: "Commerce Stream",
        badge: "Recommended",
        description: "The Commerce stream is perfect for students interested in business, finance, economics, and entrepreneurship. This path prepares you for leadership roles in the corporate world, professional accounting careers, and business management positions.",
        subjects: {
            default: {
                title: "Core Commerce Subjects",
                list: [
                    "Accountancy - Financial accounting, cost accounting, company accounts",
                    "Business Studies - Business organization, management, and entrepreneurship",
                    "Economics - Micro and macroeconomics, Indian economy",
                    "English - Business communication",
                    "Mathematics (Optional but recommended) - Statistics and business math",
                    "Optional: Computer Science, Physical Education, or Other Language"
                ]
            }
        },
        careers: [
            "Chartered Accountant (CA) - India's premier accounting qualification",
            "Company Secretary (CS) - Corporate governance professional",
            "Cost and Management Accountant (CMA)",
            "Business Manager, Entrepreneur, Startup Founder",
            "Investment Banker, Financial Analyst, Stock Broker",
            "Marketing Manager, Brand Manager, Sales Manager",
            "HR Manager, Operations Manager",
            "Economist, Business Consultant, Tax Consultant",
            "Digital Marketing Specialist, E-commerce Manager",
            "Banking & Insurance Professionals"
        ],
        entranceExams: [
            "CA Foundation (Chartered Accountancy)",
            "CS Foundation (Company Secretary)",
            "CMA Foundation (Cost Management)",
            "CLAT (Law after Commerce)",
            "IPMAT, SET (Integrated Management)",
            "BBA/BBM College Entrance Exams"
        ],
        topColleges: [
            "SRCC (Shri Ram College of Commerce), Delhi",
            "St. Xavier's College, Mumbai/Kolkata",
            "Christ University, Bangalore",
            "Loyola College, Chennai",
            "IIM Indore/Rohtak (Integrated Programs)",
            "NMIMS, Symbiosis, Narsee Monjee College"
        ],
        skills: [
            "Numerical and analytical abilities",
            "Business acumen and commercial awareness",
            "Communication and negotiation skills",
            "Financial management and planning",
            "Leadership and decision-making"
        ]
    },
    
    arts: {
        title: "Arts/Humanities Stream",
        badge: "Great Choice",
        description: "The Arts stream offers incredible diversity and flexibility, perfect for creative, analytical, and socially conscious students. This path leads to careers in law, civil services, journalism, education, psychology, social work, and creative industries.",
        subjects: {
            default: {
                title: "Core Arts/Humanities Subjects",
                list: [
                    "History - World history, Indian history, and historical analysis",
                    "Political Science - Government, politics, international relations",
                    "Geography - Physical and human geography",
                    "Economics - Economic systems and development",
                    "Psychology - Human behavior and mental processes",
                    "Sociology - Society, culture, and social issues",
                    "English Literature - Literary analysis and writing",
                    "Philosophy, Fine Arts, Home Science (based on availability)"
                ]
            }
        },
        careers: [
            "Civil Services (IAS, IPS, IFS) - Administrative services",
            "Lawyer, Judge, Legal Advisor (after studying Law)",
            "Journalist, Content Writer, Editor, Media Professional",
            "Psychologist, Counselor, Social Worker",
            "Teacher, Professor, Educational Administrator",
            "Foreign Services, Diplomat, International Relations Expert",
            "Designer, Fashion Designer, Interior Designer",
            "Event Manager, Public Relations Officer",
            "Historian, Archaeologist, Museum Curator",
            "Human Rights Activist, NGO Worker",
            "Digital Content Creator, Influencer, Blogger"
        ],
        entranceExams: [
            "UPSC (Civil Services Examination)",
            "CLAT (Law Entrance)",
            "JNU, DU, BHU Entrance (BA Programs)",
            "CUET (Central Universities)",
            "NIFT, NID (Design)",
            "IIMC (Journalism)"
        ],
        topColleges: [
            "St. Stephen's College, Delhi",
            "JNU (Jawaharlal Nehru University)",
            "DU Colleges (Hindu, Miranda House, Ramjas)",
            "Presidency University, Kolkata",
            "Jadavpur University",
            "TISS (Tata Institute of Social Sciences)",
            "National Law Universities (NLUs)",
            "Film and Television Institute of India (FTII)"
        ],
        skills: [
            "Critical thinking and analytical skills",
            "Excellent communication and writing",
            "Creativity and artistic expression",
            "Empathy and social awareness",
            "Research and investigation abilities"
        ]
    },
    
    vocational: {
        title: "Vocational/Technical Courses",
        badge: "Practical Path",
        description: "Vocational education provides industry-ready skills and practical training for immediate employment. These courses focus on hands-on learning and prepare you for specific careers in technology, hospitality, design, and other professional fields.",
        subjects: {
            default: {
                title: "Popular Vocational Streams",
                list: [
                    "Information Technology & Computer Applications",
                    "Web Development, App Development, Digital Marketing",
                    "Graphic Design, Animation, Multimedia",
                    "Hotel Management & Tourism",
                    "Fashion Design, Textile Design",
                    "Automobile Technology, Mechanical Skills",
                    "Electrical & Electronics Technology",
                    "Beauty & Wellness, Cosmetology",
                    "Agriculture & Farming Technology",
                    "Retail Management, Banking Operations"
                ]
            }
        },
        careers: [
            "Web Developer, Mobile App Developer",
            "Graphic Designer, UI/UX Designer",
            "Digital Marketing Specialist, SEO Expert",
            "Hotel Manager, Chef, Tourism Guide",
            "Fashion Designer, Boutique Owner",
            "Automobile Technician, Mechanic",
            "Electrician, Electronics Technician",
            "Beautician, Makeup Artist, Salon Owner",
            "Organic Farmer, Agriculture Entrepreneur",
            "Retail Store Manager, Bank Officer"
        ],
        entranceExams: [
            "ITI Entrance (Industrial Training)",
            "Polytechnic Diploma Entrance",
            "NIFT (Fashion Design)",
            "NCHMCT JEE (Hotel Management)",
            "NID DAT (Design)",
            "State-level Vocational Tests"
        ],
        topColleges: [
            "ITI Institutes (Government & Private)",
            "Polytechnic Colleges (State-wise)",
            "NIFT (National Institute of Fashion Technology)",
            "IHM (Institute of Hotel Management)",
            "Arena Animation, NIIT (Private Training)",
            "Pearl Academy, Vogue Institute",
            "State Government Vocational Centers"
        ],
        skills: [
            "Hands-on practical abilities",
            "Technical and technological aptitude",
            "Creativity and design thinking",
            "Entrepreneurial mindset",
            "Industry-specific expertise"
        ]
    },
    
    interdisciplinary: {
        title: "Interdisciplinary Options",
        badge: "Alternative Path",
        description: "If you have diverse interests, consider interdisciplinary programs that combine multiple fields. These modern programs are designed for students who want flexibility and exposure to various domains.",
        subjects: {
            default: {
                title: "Interdisciplinary Programs",
                list: [
                    "Liberal Arts Programs - Combine humanities, sciences, and social sciences",
                    "Business Analytics - Commerce + Technology",
                    "Biotechnology - Biology + Technology",
                    "Environmental Science - Science + Social Studies",
                    "Media & Communication - Arts + Technology",
                    "Sports Science - Science + Physical Education",
                    "Design Thinking - Arts + Business + Technology"
                ]
            }
        },
        careers: [
            "Business Analyst, Product Manager",
            "UX Researcher, Design Strategist",
            "Environmental Consultant, Sustainability Expert",
            "Sports Manager, Fitness Entrepreneur",
            "Media Producer, Content Strategist",
            "Innovation Consultant, Strategy Advisor"
        ],
        entranceExams: [
            "University-specific entrance tests",
            "CUET (Central Universities)",
            "International Baccalaureate (IB)",
            "Private university admissions"
        ],
        topColleges: [
            "Ashoka University (Liberal Arts)",
            "Flame University (Interdisciplinary)",
            "IIT Madras (Interdisciplinary Sciences)",
            "Azim Premji University",
            "OP Jindal Global University",
            "Krea University"
        ],
        skills: [
            "Adaptability and flexibility",
            "Multi-disciplinary thinking",
            "Problem-solving across domains",
            "Innovation and creativity",
            "Holistic perspective"
        ]
    }
};

// Recommendation engine
function calculateRecommendations(answers) {
    const tagScores = {};
    
    // Count tag frequencies from all answers
    answers.forEach((answer, questionIndex) => {
        const question = questions[questionIndex];
        const selectedOption = question.options.find(opt => opt.id === answer);
        
        if (selectedOption && selectedOption.tags) {
            selectedOption.tags.forEach(tag => {
                tagScores[tag] = (tagScores[tag] || 0) + 1;
            });
        }
    });
    
    // Calculate match percentages for each stream
    const streamScores = {
        science: 0,
        commerce: 0,
        arts: 0,
        vocational: 0,
        interdisciplinary: 0
    };
    
    // Science stream scoring
    streamScores.science = (
        (tagScores.science || 0) * 20 +
        (tagScores.analytical || 0) * 15 +
        (tagScores.research || 0) * 15 +
        (tagScores.engineering || 0) * 10 +
        (tagScores.medical || 0) * 10
    );
    
    // Commerce stream scoring
    streamScores.commerce = (
        (tagScores.commerce || 0) * 20 +
        (tagScores.business || 0) * 20 +
        (tagScores.finance || 0) * 15 +
        (tagScores.entrepreneurship || 0) * 10 +
        (tagScores.leadership || 0) * 10
    );
    
    // Arts stream scoring
    streamScores.arts = (
        (tagScores.arts || 0) * 20 +
        (tagScores.creative || 0) * 15 +
        (tagScores.social || 0) * 15 +
        (tagScores.service || 0) * 10 +
        (tagScores.design || 0) * 10
    );
    
    // Vocational stream scoring
    streamScores.vocational = (
        (tagScores.technical || 0) * 20 +
        (tagScores.practical || 0) * 20 +
        (tagScores.vocational || 0) * 15
    );
    
    // Interdisciplinary scoring (for diverse interests)
    const uniqueTags = Object.keys(tagScores).length;
    streamScores.interdisciplinary = uniqueTags * 8;
    
    // Sort streams by score
    const sortedStreams = Object.entries(streamScores)
        .sort((a, b) => b[1] - a[1])
        .filter(([_, score]) => score > 0);
    
    // Normalize scores to percentages
    const maxScore = Math.max(...sortedStreams.map(([_, score]) => score));
    const recommendations = sortedStreams.slice(0, 3).map(([stream, score]) => ({
        stream,
        match: Math.round((score / maxScore) * 100)
    }));
    
    return recommendations;
}