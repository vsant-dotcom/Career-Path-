// State management
let currentQuestionIndex = 0;
let userAnswers = [];

// DOM Elements
const welcomeScreen = document.getElementById('welcomeScreen');
const questionnaireScreen = document.getElementById('questionnaireScreen');
const resultsScreen = document.getElementById('resultsScreen');
const startBtn = document.getElementById('startBtn');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const submitBtn = document.getElementById('submitBtn');
const restartBtn = document.getElementById('restartBtn');
const printBtn = document.getElementById('printBtn');
const questionContainer = document.getElementById('questionContainer');
const recommendationsContainer = document.getElementById('recommendationsContainer');
const progressFill = document.getElementById('progressFill');
const currentQuestionSpan = document.getElementById('currentQuestion');
const totalQuestionsSpan = document.getElementById('totalQuestions');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    totalQuestionsSpan.textContent = questions.length;
    
    // Event listeners
    startBtn.addEventListener('click', startQuestionnaire);
    prevBtn.addEventListener('click', previousQuestion);
    nextBtn.addEventListener('click', nextQuestion);
    submitBtn.addEventListener('click', showResults);
    restartBtn.addEventListener('click', restart);
    printBtn.addEventListener('click', () => window.print());
});

// Start questionnaire
function startQuestionnaire() {
    showScreen('questionnaire');
    renderQuestion();
}

// Show specific screen
function showScreen(screen) {
    welcomeScreen.classList.remove('active');
    questionnaireScreen.classList.remove('active');
    resultsScreen.classList.remove('active');
    
    if (screen === 'welcome') {
        welcomeScreen.classList.add('active');
    } else if (screen === 'questionnaire') {
        questionnaireScreen.classList.add('active');
    } else if (screen === 'results') {
        resultsScreen.classList.add('active');
    }
}

// Render current question
function renderQuestion() {
    const question = questions[currentQuestionIndex];
    
    questionContainer.innerHTML = `
        <div class="question">
            <h2 class="question-title">
                <i class="${question.icon}"></i>
                ${question.question}
            </h2>
            <div class="options-container" id="optionsContainer">
                ${question.options.map(option => `
                    <div class="option-card" data-option-id="${option.id}">
                        <i class="${option.icon} option-icon"></i>
                        <div class="option-content">
                            <div class="option-title">${option.title}</div>
                            <div class="option-description">${option.description}</div>
                        </div>
                        <div class="option-radio"></div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
    
    // Add click handlers to options
    const optionCards = document.querySelectorAll('.option-card');
    optionCards.forEach(card => {
        card.addEventListener('click', () => selectOption(card));
    });
    
    // Restore previous answer if exists
    if (userAnswers[currentQuestionIndex]) {
        const selectedCard = document.querySelector(`[data-option-id="${userAnswers[currentQuestionIndex]}"]`);
        if (selectedCard) {
            selectedCard.classList.add('selected');
            nextBtn.disabled = false;
        }
    }
    
    updateProgress();
    updateNavigationButtons();
}

// Select option
function selectOption(card) {
    // Remove previous selection
    document.querySelectorAll('.option-card').forEach(c => c.classList.remove('selected'));
    
    // Add new selection
    card.classList.add('selected');
    
    // Store answer
    const optionId = card.getAttribute('data-option-id');
    userAnswers[currentQuestionIndex] = optionId;
    
    // Enable next button
    nextBtn.disabled = false;
    submitBtn.disabled = false;
}

// Update progress bar
function updateProgress() {
    const progress = ((currentQuestionIndex + 1) / questions.length) * 100;
    progressFill.style.width = `${progress}%`;
    currentQuestionSpan.textContent = currentQuestionIndex + 1;
}

// Update navigation buttons
function updateNavigationButtons() {
    // Previous button
    prevBtn.style.display = currentQuestionIndex > 0 ? 'inline-flex' : 'none';
    
    // Next/Submit button
    if (currentQuestionIndex === questions.length - 1) {
        nextBtn.style.display = 'none';
        submitBtn.style.display = 'inline-flex';
        submitBtn.disabled = !userAnswers[currentQuestionIndex];
    } else {
        nextBtn.style.display = 'inline-flex';
        submitBtn.style.display = 'none';
        nextBtn.disabled = !userAnswers[currentQuestionIndex];
    }
}

// Navigate to previous question
function previousQuestion() {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        renderQuestion();
    }
}

// Navigate to next question
function nextQuestion() {
    if (currentQuestionIndex < questions.length - 1) {
        currentQuestionIndex++;
        renderQuestion();
    }
}

// Show results
function showResults() {
    if (userAnswers.length !== questions.length) {
        alert('Please answer all questions before submitting.');
        return;
    }
    
    const recommendations = calculateRecommendations(userAnswers);
    renderRecommendations(recommendations);
    showScreen('results');
    window.scrollTo(0, 0);
}

// Render recommendations
function renderRecommendations(recommendations) {
    recommendationsContainer.innerHTML = recommendations.map((rec, index) => {
        const pathData = studyPaths[rec.stream];
        const cardClass = index === 0 ? 'primary' : (index === 1 ? 'secondary' : 'tertiary');
        
        return `
            <div class="recommendation-card ${cardClass}">
                <div class="recommendation-header">
                    <span class="recommendation-badge">${pathData.badge}</span>
                    <h2 class="recommendation-title">${pathData.title}</h2>
                    <span class="recommendation-match">${rec.match}% Match</span>
                </div>
                
                <p class="recommendation-description">${pathData.description}</p>
                
                ${renderSubjects(pathData.subjects)}
                
                <div class="recommendation-section">
                    <h3 class="section-title">
                        <i class="fas fa-briefcase"></i>
                        Career Opportunities
                    </h3>
                    <ul class="careers-list">
                        ${pathData.careers.slice(0, 8).map(career => `<li>${career}</li>`).join('')}
                    </ul>
                </div>
                
                ${pathData.entranceExams ? `
                    <div class="recommendation-section">
                        <h3 class="section-title">
                            <i class="fas fa-file-alt"></i>
                            Key Entrance Exams
                        </h3>
                        <div class="section-content">
                            ${pathData.entranceExams.join(' • ')}
                        </div>
                    </div>
                ` : ''}
                
                <div class="recommendation-section">
                    <h3 class="section-title">
                        <i class="fas fa-university"></i>
                        Top Colleges & Institutions
                    </h3>
                    <ul class="colleges-list">
                        ${pathData.topColleges.slice(0, 6).map(college => `<li>${college}</li>`).join('')}
                    </ul>
                </div>
                
                <div class="recommendation-section">
                    <h3 class="section-title">
                        <i class="fas fa-check-circle"></i>
                        Skills You'll Develop
                    </h3>
                    <div class="section-content">
                        ${pathData.skills.join(' • ')}
                    </div>
                </div>
                
                ${index === 0 ? `
                    <div class="highlight-box">
                        <strong>💡 Why This is Your Best Match:</strong><br>
                        Based on your interests, strengths, and career goals, this stream aligns perfectly with your profile. 
                        You have a ${rec.match}% compatibility with this path, which indicates strong potential for success and satisfaction.
                    </div>
                ` : ''}
            </div>
        `;
    }).join('');
}

// Render subjects section
function renderSubjects(subjects) {
    if (!subjects) return '';
    
    return Object.entries(subjects).map(([key, subjectData]) => `
        <div class="recommendation-section">
            <h3 class="section-title">
                <i class="fas fa-book"></i>
                ${subjectData.title}
            </h3>
            <ul class="subjects-list">
                ${subjectData.list.map(subject => `<li>${subject}</li>`).join('')}
            </ul>
        </div>
    `).join('');
}

// Restart questionnaire
function restart() {
    currentQuestionIndex = 0;
    userAnswers = [];
    showScreen('welcome');
    window.scrollTo(0, 0);
}

// Add smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});