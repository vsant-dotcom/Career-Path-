// Questions database with detailed options
const questions = [
    {
        id: 1,
        question: "Which subjects do you find most interesting and enjoy studying?",
        icon: "fas fa-book",
        options: [
            {
                id: "a",
                icon: "fas fa-flask",
                title: "Science & Mathematics",
                description: "Physics, Chemistry, Biology, Mathematics - I love experiments and problem-solving",
                tags: ["science", "analytical", "research"]
            },
            {
                id: "b",
                icon: "fas fa-chart-line",
                title: "Commerce & Business",
                description: "Accounts, Economics, Business Studies - I'm interested in money, markets, and business",
                tags: ["commerce", "business", "finance"]
            },
            {
                id: "c",
                icon: "fas fa-palette",
                title: "Arts & Humanities",
                description: "History, Literature, Psychology, Sociology - I love creativity and human understanding",
                tags: ["arts", "creative", "social"]
            },
            {
                id: "d",
                icon: "fas fa-tools",
                title: "Practical & Technical Skills",
                description: "Technology, Design, Crafts - I prefer hands-on learning and practical applications",
                tags: ["technical", "practical", "vocational"]
            }
        ]
    },
    {
        id: 2,
        question: "What type of career appeals to you the most?",
        icon: "fas fa-briefcase",
        options: [
            {
                id: "a",
                icon: "fas fa-laptop-code",
                title: "Technology & Innovation",
                description: "Engineer, Developer, Data Scientist - Building and innovating with technology",
                tags: ["science", "technical", "engineering"]
            },
            {
                id: "b",
                icon: "fas fa-user-md",
                title: "Healthcare & Medicine",
                description: "Doctor, Nurse, Therapist - Helping people and working in healthcare",
                tags: ["science", "medical", "service"]
            },
            {
                id: "c",
                icon: "fas fa-balance-scale",
                title: "Business & Management",
                description: "Entrepreneur, Manager, Accountant, CA - Leading teams and managing business",
                tags: ["commerce", "business", "leadership"]
            },
            {
                id: "d",
                icon: "fas fa-lightbulb",
                title: "Creative & Design",
                description: "Designer, Artist, Writer, Architect - Creating and expressing ideas visually",
                tags: ["arts", "creative", "design"]
            },
            {
                id: "e",
                icon: "fas fa-users",
                title: "Social Service & Education",
                description: "Teacher, Social Worker, Counselor - Making a difference in society",
                tags: ["arts", "social", "service"]
            }
        ]
    },
    {
        id: 3,
        question: "How do you prefer to learn and solve problems?",
        icon: "fas fa-brain",
        options: [
            {
                id: "a",
                icon: "fas fa-calculator",
                title: "Logical & Analytical",
                description: "I love numbers, formulas, and systematic problem-solving approaches",
                tags: ["analytical", "science", "commerce"]
            },
            {
                id: "b",
                icon: "fas fa-hands-helping",
                title: "Practical & Hands-on",
                description: "I learn best by doing and experimenting with real-world applications",
                tags: ["practical", "technical", "vocational"]
            },
            {
                id: "c",
                icon: "fas fa-paint-brush",
                title: "Creative & Innovative",
                description: "I think outside the box and enjoy finding unique, creative solutions",
                tags: ["creative", "arts", "design"]
            },
            {
                id: "d",
                icon: "fas fa-book-reader",
                title: "Research & Understanding",
                description: "I like to deeply understand concepts, read extensively, and analyze information",
                tags: ["research", "analytical", "arts"]
            }
        ]
    },
    {
        id: 4,
        question: "What are your strongest skills or abilities?",
        icon: "fas fa-star",
        options: [
            {
                id: "a",
                icon: "fas fa-atom",
                title: "Scientific & Analytical Thinking",
                description: "Strong in mathematics, logic, scientific reasoning, and problem-solving",
                tags: ["science", "analytical", "engineering"]
            },
            {
                id: "b",
                icon: "fas fa-comments",
                title: "Communication & Social Skills",
                description: "Good at expressing ideas, understanding people, and working in teams",
                tags: ["social", "arts", "service"]
            },
            {
                id: "c",
                icon: "fas fa-money-bill-wave",
                title: "Business & Financial Acumen",
                description: "Understanding of money management, business concepts, and economics",
                tags: ["commerce", "business", "finance"]
            },
            {
                id: "d",
                icon: "fas fa-pencil-ruler",
                title: "Creative & Design Skills",
                description: "Artistic abilities, design thinking, creativity, and aesthetic sense",
                tags: ["creative", "arts", "design"]
            },
            {
                id: "e",
                icon: "fas fa-wrench",
                title: "Technical & Practical Skills",
                description: "Good with technology, building things, and hands-on technical work",
                tags: ["technical", "practical", "vocational"]
            }
        ]
    },
    {
        id: 5,
        question: "What are your long-term goals after higher education?",
        icon: "fas fa-flag-checkered",
        options: [
            {
                id: "a",
                icon: "fas fa-university",
                title: "Professional Degree & Career",
                description: "Pursue professional courses (Engineering, Medicine, CA, Law) and build a stable career",
                tags: ["science", "commerce", "professional"]
            },
            {
                id: "b",
                icon: "fas fa-rocket",
                title: "Entrepreneurship & Business",
                description: "Start my own business or venture, be my own boss",
                tags: ["commerce", "business", "entrepreneurship"]
            },
            {
                id: "c",
                icon: "fas fa-globe",
                title: "Research & Innovation",
                description: "Pursue research, make discoveries, contribute to knowledge and innovation",
                tags: ["science", "research", "academic"]
            },
            {
                id: "d",
                icon: "fas fa-heart",
                title: "Creative Work & Expression",
                description: "Work in creative fields, express myself, and create meaningful art/content",
                tags: ["arts", "creative", "design"]
            },
            {
                id: "e",
                icon: "fas fa-hands-helping",
                title: "Social Impact & Service",
                description: "Make a positive impact on society, help others, and contribute to social causes",
                tags: ["social", "service", "arts"]
            }
        ]
    }
];